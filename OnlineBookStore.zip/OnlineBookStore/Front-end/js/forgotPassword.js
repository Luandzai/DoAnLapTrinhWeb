function sendResetToken() {
    const email = document.getElementById("email").value;  // Lấy email từ input

    if (!email) {
        alert("Email không được để trống!");
        return;
    }

    const request = {
        email: email
    };

    fetch('http://localhost:5000/api/account/forgot-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(request)
    })
    .then(response => response.json())
    .then(data => {
        if (data.message) {
            alert(data.message);
        } else {
            alert("Đã có lỗi xảy ra.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
