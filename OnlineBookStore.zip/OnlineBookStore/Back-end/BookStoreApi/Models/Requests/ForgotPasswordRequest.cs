namespace BookStoreApi.Models.Requests
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }
}
